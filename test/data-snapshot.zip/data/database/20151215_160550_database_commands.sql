ALTER TABLE "mfhierarchy$diagramfilter"
	DROP COLUMN "filteronmodules";
ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "filteronmodules" VARCHAR_IGNORECASE(25) NULL;
UPDATE "mfhierarchy$diagramfilter"
 SET "filteronmodules" = 'Yes__use_as_AND_statement';
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '216ebd34-4b42-43b4-8f29-2abb49a75756', 
"attribute_name" = 'FilterOnModules', 
"column_name" = 'filteronmodules', 
"type" = 40, 
"length" = 25, 
"default_value" = 'Yes__use_as_AND_statement', 
"is_auto_number" = false
 WHERE "id" = '2d42addd-2559-44b0-a018-28bfca34e36a';
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151215 16:05:50';
