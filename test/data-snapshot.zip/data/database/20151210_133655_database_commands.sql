ALTER TABLE "mfhierarchy$mfaction"
	ADD "createddate" TIMESTAMP NULL;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('0b66d155-87f2-362f-92a6-ce46d1f09f21', 
'8edfcd49-7bd1-4d10-a59f-0ec6e3f536a9', 
'createdDate', 
'createddate', 
20, 
0, 
'', 
false);
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151210 13:15:20';
