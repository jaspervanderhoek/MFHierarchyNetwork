ALTER TABLE "mfhierarchy$diagramfilter" ALTER COLUMN "nrofstepstoinclude" RENAME TO "nrofparentstoinclude";
ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "nrofchildrentoinclude" INT NULL;
UPDATE "mfhierarchy$diagramfilter"
 SET "nrofchildrentoinclude" = 1;
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '216ebd34-4b42-43b4-8f29-2abb49a75756', 
"attribute_name" = 'NrOfParentsToInclude', 
"column_name" = 'nrofparentstoinclude', 
"type" = 3, 
"length" = 0, 
"default_value" = '1', 
"is_auto_number" = false
 WHERE "id" = '826bec70-defc-41fb-8584-77b904a0652c';
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('a0e2f2c3-8d42-441a-b140-da980bad95b3', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'NrOfChildrenToInclude', 
'nrofchildrentoinclude', 
3, 
0, 
'1', 
false);
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151215 16:25:49';
