CREATE TABLE "mfhierarchy$microflow_actioncall" (
	"mfhierarchy$microflowid" BIGINT NOT NULL,
	"mfhierarchy$actionid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$microflowid","mfhierarchy$actionid"));
CREATE INDEX "idx_mfhierarchy$microflow_actioncall_mfhierarchy$action_mfhierarchy$microflow" ON "mfhierarchy$microflow_actioncall"
	("mfhierarchy$actionid","mfhierarchy$microflowid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('756f8aba-65fe-4dd6-b8d3-e14bfa91fb0a', 
'MFHierarchy.Microflow_ActionCall', 
'mfhierarchy$microflow_actioncall', 
'7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'mfhierarchy$microflowid', 
'mfhierarchy$actionid', 
'idx_mfhierarchy$microflow_actioncall_mfhierarchy$action_mfhierarchy$microflow');
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151215 14:02:23';
