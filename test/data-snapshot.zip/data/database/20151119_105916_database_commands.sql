ALTER TABLE "mfhierarchy$action" ALTER COLUMN "name" RENAME TO "completename";
ALTER TABLE "mfhierarchy$action"
	ADD "modulename" VARCHAR_IGNORECASE(200) NULL;
ALTER TABLE "mfhierarchy$action"
	ADD "actionname" VARCHAR_IGNORECASE(200) NULL;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('8fdcbae2-ede2-4c6e-b654-21bd02f94023', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'ActionName', 
'actionname', 
30, 
200, 
'', 
false);
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '09449d31-6812-4bb2-9506-efeb57486913', 
"attribute_name" = 'CompleteName', 
"column_name" = 'completename', 
"type" = 30, 
"length" = 400, 
"default_value" = '', 
"is_auto_number" = false
 WHERE "id" = 'f059eabd-6351-4636-b983-1f679db0b8f3';
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('b78cf9d9-c7aa-42be-a4d8-7ebd8abeb15d', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'ModuleName', 
'modulename', 
30, 
200, 
'', 
false);
ALTER TABLE "mfhierarchy$mfaction" ALTER COLUMN "callsmf" RENAME TO "actioncall_modulename";
ALTER TABLE "mfhierarchy$mfaction" ALTER COLUMN "currentmf" RENAME TO "currentmfmodule";
ALTER TABLE "mfhierarchy$mfaction"
	ADD "currentmfname" VARCHAR_IGNORECASE(200) NULL;
ALTER TABLE "mfhierarchy$mfaction"
	ADD "actioncall_actionname" VARCHAR_IGNORECASE(200) NULL;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('4317bee3-c0d3-4a38-a503-0575eccf3faa', 
'8edfcd49-7bd1-4d10-a59f-0ec6e3f536a9', 
'ActionCall_ActionName', 
'actioncall_actionname', 
30, 
200, 
'', 
false);
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '8edfcd49-7bd1-4d10-a59f-0ec6e3f536a9', 
"attribute_name" = 'ActionCall_ModuleName', 
"column_name" = 'actioncall_modulename', 
"type" = 30, 
"length" = 200, 
"default_value" = '', 
"is_auto_number" = false
 WHERE "id" = '448bc0eb-ced3-4c2b-820b-41b613fdf880';
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '8edfcd49-7bd1-4d10-a59f-0ec6e3f536a9', 
"attribute_name" = 'CurrentMFModule', 
"column_name" = 'currentmfmodule', 
"type" = 30, 
"length" = 200, 
"default_value" = '', 
"is_auto_number" = false
 WHERE "id" = 'cc2d6c14-ea25-4b0c-96f0-f1329a509f9b';
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('97351bde-547c-4f58-ac0c-57e0fe17b473', 
'8edfcd49-7bd1-4d10-a59f-0ec6e3f536a9', 
'CurrentMFName', 
'currentmfname', 
30, 
200, 
'', 
false);
CREATE TABLE "mfhierarchy$action_module" (
	"mfhierarchy$actionid" BIGINT NOT NULL,
	"mfhierarchy$moduleid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$actionid","mfhierarchy$moduleid"));
CREATE INDEX "idx_mfhierarchy$action_module_mfhierarchy$module_mfhierarchy$action" ON "mfhierarchy$action_module"
	("mfhierarchy$moduleid","mfhierarchy$actionid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('3ade3ae6-a77f-4f74-a7ef-ffcccaf5c58c', 
'MFHierarchy.Action_Module', 
'mfhierarchy$action_module', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'd245cab5-78ea-4607-a5eb-ae4a3447c4ec', 
'mfhierarchy$actionid', 
'mfhierarchy$moduleid', 
'idx_mfhierarchy$action_module_mfhierarchy$module_mfhierarchy$action');
CREATE TABLE "mfhierarchy$module" (
	"id" BIGINT NOT NULL,
	"name" VARCHAR_IGNORECASE(200) NULL,
	"changeddate" TIMESTAMP NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name")
 VALUES ('d245cab5-78ea-4607-a5eb-ae4a3447c4ec', 
'MFHierarchy.Module', 
'mfhierarchy$module');
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('60efc0fe-7c0b-4a3a-8d65-e4f531dccf0b', 
'd245cab5-78ea-4607-a5eb-ae4a3447c4ec', 
'Name', 
'name', 
30, 
200, 
'', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('095ccd43-d30a-3bd4-809a-f401bb950562', 
'd245cab5-78ea-4607-a5eb-ae4a3447c4ec', 
'changedDate', 
'changeddate', 
20, 
0, 
'', 
false);
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151119 10:58:58';
