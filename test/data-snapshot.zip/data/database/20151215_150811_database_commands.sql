CREATE TABLE "mfhierarchy$diagramfilter_excludefromactionfilter" (
	"mfhierarchy$diagramfilterid" BIGINT NOT NULL,
	"mfhierarchy$actionid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$diagramfilterid","mfhierarchy$actionid"));
CREATE INDEX "idx_mfhierarchy$diagramfilter_excludefromactionfilter_mfhierarchy$action_mfhierarchy$diagramfilter" ON "mfhierarchy$diagramfilter_excludefromactionfilter"
	("mfhierarchy$actionid","mfhierarchy$diagramfilterid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('5aaf0923-bf94-46f1-8e0e-5cc88362a04e', 
'MFHierarchy.DiagramFilter_ExcludeFromActionFilter', 
'mfhierarchy$diagramfilter_excludefromactionfilter', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'mfhierarchy$diagramfilterid', 
'mfhierarchy$actionid', 
'idx_mfhierarchy$diagramfilter_excludefromactionfilter_mfhierarchy$action_mfhierarchy$diagramfilter');
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151215 15:08:10';
