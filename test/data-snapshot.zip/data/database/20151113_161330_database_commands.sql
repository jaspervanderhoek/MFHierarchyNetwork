ALTER TABLE "mfhierarchy$mfaction" ALTER COLUMN "parentmf" RENAME TO "callsmf";
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '8edfcd49-7bd1-4d10-a59f-0ec6e3f536a9', 
"attribute_name" = 'CallsMF', 
"column_name" = 'callsmf', 
"type" = 30, 
"length" = 200, 
"default_value" = '', 
"is_auto_number" = false
 WHERE "id" = '448bc0eb-ced3-4c2b-820b-41b613fdf880';
CREATE TABLE "mfhierarchy$microflow" (
	"id" BIGINT NOT NULL,
	"name" VARCHAR_IGNORECASE(200) NULL,
	"changeddate" TIMESTAMP NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name")
 VALUES ('7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'MFHierarchy.Microflow', 
'mfhierarchy$microflow');
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('8d0f3b4b-840c-46e0-8793-61de1f9553ec', 
'7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'Name', 
'name', 
30, 
200, 
'', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('2c1d5f95-4939-3176-a204-9adb827fe658', 
'7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'changedDate', 
'changeddate', 
20, 
0, 
'', 
false);
CREATE TABLE "mfhierarchy$activity" (
	"id" BIGINT NOT NULL,
	"changeddate" TIMESTAMP NULL,
	"action" VARCHAR_IGNORECASE(300) NULL,
	"activitytype" VARCHAR_IGNORECASE(200) NULL,
	"depth" INT NULL,
	"sequence" INT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name")
 VALUES ('cdadffb6-2791-4fcb-ba00-3ac6db905858', 
'MFHierarchy.Activity', 
'mfhierarchy$activity');
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('2e419843-7a42-329c-ac66-ab19c9e476d1', 
'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
'changedDate', 
'changeddate', 
20, 
0, 
'', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('b0cb14f8-6c4b-4b12-a159-c1bb3e4a752a', 
'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
'Action', 
'action', 
30, 
300, 
'', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('0126f1f2-b414-4dd0-a291-8156179b2a4e', 
'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
'ActivityType', 
'activitytype', 
30, 
200, 
'', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('01a4d789-a61b-402d-9ba7-200cbd9b642c', 
'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
'Depth', 
'depth', 
3, 
0, 
'', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('dd8f4fbd-0a9e-4bed-95c2-de01add3487b', 
'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
'Sequence', 
'sequence', 
3, 
0, 
'', 
false);
CREATE TABLE "mfhierarchy$activity_microflowcall" (
	"mfhierarchy$activityid" BIGINT NOT NULL,
	"mfhierarchy$microflowid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$activityid","mfhierarchy$microflowid"));
CREATE INDEX "idx_mfhierarchy$activity_microflowcall_mfhierarchy$microflow_mfhierarchy$activity" ON "mfhierarchy$activity_microflowcall"
	("mfhierarchy$microflowid","mfhierarchy$activityid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('583b3b6c-23eb-45f2-8f83-22bbb8eda6af', 
'MFHierarchy.Activity_MicroflowCall', 
'mfhierarchy$activity_microflowcall', 
'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
'7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'mfhierarchy$activityid', 
'mfhierarchy$microflowid', 
'idx_mfhierarchy$activity_microflowcall_mfhierarchy$microflow_mfhierarchy$activity');
CREATE TABLE "mfhierarchy$activity_microflow" (
	"mfhierarchy$activityid" BIGINT NOT NULL,
	"mfhierarchy$microflowid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$activityid","mfhierarchy$microflowid"));
CREATE INDEX "idx_mfhierarchy$activity_microflow_mfhierarchy$microflow_mfhierarchy$activity" ON "mfhierarchy$activity_microflow"
	("mfhierarchy$microflowid","mfhierarchy$activityid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('87b82f94-844d-44c0-891b-632d067b36bc', 
'MFHierarchy.Activity_Microflow', 
'mfhierarchy$activity_microflow', 
'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
'7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'mfhierarchy$activityid', 
'mfhierarchy$microflowid', 
'idx_mfhierarchy$activity_microflow_mfhierarchy$microflow_mfhierarchy$activity');
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151113 16:13:29';
