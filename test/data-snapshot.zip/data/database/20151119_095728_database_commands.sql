ALTER TABLE "mfhierarchy$action"
	ADD "hovertext" VARCHAR_IGNORECASE(800) NULL;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('29995955-93d1-48ad-9b8a-34ca98dcab73', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'HoverText', 
'hovertext', 
30, 
800, 
'', 
false);
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151119 09:57:14';
