ALTER TABLE "mfhierarchy$diagramfilter"
	DROP COLUMN "isdefault";
ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "filtertype" VARCHAR_IGNORECASE(8) NULL;
ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "reftext" VARCHAR_IGNORECASE(200) NULL;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('ae53e52e-14ee-4737-a29f-174f995d71b8', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'RefText', 
'reftext', 
30, 
200, 
'', 
false);
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '216ebd34-4b42-43b4-8f29-2abb49a75756', 
"attribute_name" = 'FilterType', 
"column_name" = 'filtertype', 
"type" = 40, 
"length" = 8, 
"default_value" = '', 
"is_auto_number" = false
 WHERE "id" = 'ff02654d-ca0f-4bdf-ae79-defc64281be8';
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151216 12:21:34';
