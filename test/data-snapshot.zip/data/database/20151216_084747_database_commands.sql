ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "isdefault" BOOLEAN NULL;
UPDATE "mfhierarchy$diagramfilter"
 SET "isdefault" = false;
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '216ebd34-4b42-43b4-8f29-2abb49a75756', 
"attribute_name" = 'IncludeSpecificActions', 
"column_name" = 'includespecificactions', 
"type" = 10, 
"length" = 0, 
"default_value" = 'true', 
"is_auto_number" = false
 WHERE "id" = '0086726b-dbfb-41e3-b37c-85c39d789f2e';
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('ff02654d-ca0f-4bdf-ae79-defc64281be8', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'IsDefault', 
'isdefault', 
10, 
0, 
'false', 
false);
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '216ebd34-4b42-43b4-8f29-2abb49a75756', 
"attribute_name" = 'FilterOnModules', 
"column_name" = 'filteronmodules', 
"type" = 40, 
"length" = 25, 
"default_value" = 'No', 
"is_auto_number" = false
 WHERE "id" = '2d42addd-2559-44b0-a018-28bfca34e36a';
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151216 08:47:43';
