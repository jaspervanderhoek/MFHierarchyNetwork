ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "includespecificactions" BOOLEAN NULL;
UPDATE "mfhierarchy$diagramfilter"
 SET "includespecificactions" = false;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('0086726b-dbfb-41e3-b37c-85c39d789f2e', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'IncludeSpecificActions', 
'includespecificactions', 
10, 
0, 
'false', 
false);
CREATE TABLE "mfhierarchy$diagramfilter_action" (
	"mfhierarchy$diagramfilterid" BIGINT NOT NULL,
	"mfhierarchy$actionid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$diagramfilterid","mfhierarchy$actionid"));
CREATE INDEX "idx_mfhierarchy$diagramfilter_action_mfhierarchy$action_mfhierarchy$diagramfilter" ON "mfhierarchy$diagramfilter_action"
	("mfhierarchy$actionid","mfhierarchy$diagramfilterid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('e2aa02e2-9636-48c3-9d59-b90d7d0f0432', 
'MFHierarchy.DiagramFilter_Action', 
'mfhierarchy$diagramfilter_action', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'mfhierarchy$diagramfilterid', 
'mfhierarchy$actionid', 
'idx_mfhierarchy$diagramfilter_action_mfhierarchy$action_mfhierarchy$diagramfilter');
CREATE TABLE "mfhierarchy$diagramfilter_action_single" (
	"mfhierarchy$diagramfilterid" BIGINT NOT NULL,
	"mfhierarchy$actionid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$diagramfilterid","mfhierarchy$actionid"));
CREATE INDEX "idx_mfhierarchy$diagramfilter_action_single_mfhierarchy$action_mfhierarchy$diagramfilter" ON "mfhierarchy$diagramfilter_action_single"
	("mfhierarchy$actionid","mfhierarchy$diagramfilterid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('327505b9-5b30-4843-a128-153c6775f12a', 
'MFHierarchy.DiagramFilter_Action_Single', 
'mfhierarchy$diagramfilter_action_single', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'mfhierarchy$diagramfilterid', 
'mfhierarchy$actionid', 
'idx_mfhierarchy$diagramfilter_action_single_mfhierarchy$action_mfhierarchy$diagramfilter');
CREATE TABLE "mfhierarchy$actionfilter" (
	"id" BIGINT NOT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name")
 VALUES ('4be4c97a-2f95-45d7-b961-880682d4674f', 
'MFHierarchy.ActionFilter', 
'mfhierarchy$actionfilter');
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151119 17:23:09';
