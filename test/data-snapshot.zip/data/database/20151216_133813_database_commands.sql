CREATE TABLE "mfhierarchy$queryhelper" (
	"id" BIGINT NOT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name")
 VALUES ('c68ff430-2220-4626-a8c0-76cd9f0e2190', 
'MFHierarchy.QueryHelper', 
'mfhierarchy$queryhelper');
CREATE TABLE "mfhierarchy$actionref" (
	"mfhierarchy$queryhelperid" BIGINT NOT NULL,
	"mfhierarchy$actionid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$queryhelperid","mfhierarchy$actionid"));
CREATE INDEX "idx_mfhierarchy$actionref_mfhierarchy$action_mfhierarchy$queryhelper" ON "mfhierarchy$actionref"
	("mfhierarchy$actionid","mfhierarchy$queryhelperid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('b4e8bc34-3acb-4fc0-bd4d-b04e728aec17', 
'MFHierarchy.ActionRef', 
'mfhierarchy$actionref', 
'c68ff430-2220-4626-a8c0-76cd9f0e2190', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'mfhierarchy$queryhelperid', 
'mfhierarchy$actionid', 
'idx_mfhierarchy$actionref_mfhierarchy$action_mfhierarchy$queryhelper');
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151216 13:38:11';
