DROP INDEX "idx_mfhierarchy$display_microflow_mfhierarchy$microflow_mfhierarchy$display";
ALTER TABLE "mfhierarchy$display" RENAME TO "mfhierarchy$diagramfilter";
ALTER TABLE "mfhierarchy$display_microflow" RENAME TO "mfhierarchy$diagramfilter_microflow";
ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "_cacheburst" INT NULL;
UPDATE "mfhierarchy$diagramfilter"
 SET "_cacheburst" = 0;
UPDATE "mendixsystem$entity"
 SET "entity_name" = 'MFHierarchy.DiagramFilter', 
"table_name" = 'mfhierarchy$diagramfilter', 
"superentity_id" = NULL
 WHERE "id" = '216ebd34-4b42-43b4-8f29-2abb49a75756';
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('7ab0249a-1d7b-465f-97b5-009386b19a82', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'_cacheBurst', 
'_cacheburst', 
3, 
0, 
'0', 
false);
ALTER TABLE "mfhierarchy$diagramfilter_microflow" ALTER COLUMN "mfhierarchy$displayid" RENAME TO "mfhierarchy$diagramfilterid";
CREATE INDEX "idx_mfhierarchy$diagramfilter_microflow_mfhierarchy$microflow_mfhierarchy$diagramfilter" ON "mfhierarchy$diagramfilter_microflow"
	("mfhierarchy$microflowid","mfhierarchy$diagramfilterid");
UPDATE "mendixsystem$association"
 SET "association_name" = 'MFHierarchy.DiagramFilter_Microflow', 
"table_name" = 'mfhierarchy$diagramfilter_microflow', 
"parent_entity_id" = '216ebd34-4b42-43b4-8f29-2abb49a75756', 
"child_entity_id" = '7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
"parent_column_name" = 'mfhierarchy$diagramfilterid', 
"child_column_name" = 'mfhierarchy$microflowid', 
"pk_index_name" = NULL, 
"index_name" = 'idx_mfhierarchy$diagramfilter_microflow_mfhierarchy$microflow_mfhierarchy$diagramfilter'
 WHERE "id" = '9c7a48e9-f4e6-45e7-9aef-c392244232e9';
CREATE TABLE "mfhierarchy$diagramfilter_module" (
	"mfhierarchy$diagramfilterid" BIGINT NOT NULL,
	"mfhierarchy$moduleid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$diagramfilterid","mfhierarchy$moduleid"));
CREATE INDEX "idx_mfhierarchy$diagramfilter_module_mfhierarchy$module_mfhierarchy$diagramfilter" ON "mfhierarchy$diagramfilter_module"
	("mfhierarchy$moduleid","mfhierarchy$diagramfilterid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('fc667552-2911-4de0-be6f-0367397c5ab0', 
'MFHierarchy.DiagramFilter_Module', 
'mfhierarchy$diagramfilter_module', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'd245cab5-78ea-4607-a5eb-ae4a3447c4ec', 
'mfhierarchy$diagramfilterid', 
'mfhierarchy$moduleid', 
'idx_mfhierarchy$diagramfilter_module_mfhierarchy$module_mfhierarchy$diagramfilter');
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151119 16:47:24';
