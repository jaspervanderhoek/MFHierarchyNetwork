ALTER TABLE "mfhierarchy$diagramfilter"
	DROP COLUMN "includeusedmicroflows";
ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "nrofstepstoinclude" INT NULL;
UPDATE "mfhierarchy$diagramfilter"
 SET "nrofstepstoinclude" = 1;
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '216ebd34-4b42-43b4-8f29-2abb49a75756', 
"attribute_name" = 'NrOfStepsToInclude', 
"column_name" = 'nrofstepstoinclude', 
"type" = 3, 
"length" = 0, 
"default_value" = '1', 
"is_auto_number" = false
 WHERE "id" = '826bec70-defc-41fb-8584-77b904a0652c';
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151215 14:28:37';
