ALTER TABLE "mfhierarchy$action"
	DROP COLUMN "size";
DELETE FROM "mendixsystem$attribute" 
 WHERE "id" = '8c37bb9a-8773-46a1-b5bb-d04460ed414f';
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151118 15:13:23';
