ALTER TABLE "mfhierarchy$microflow"
	ADD "actions" INT NULL;
UPDATE "mfhierarchy$microflow"
 SET "actions" = 0;
ALTER TABLE "mfhierarchy$microflow"
	ADD "usages" INT NULL;
UPDATE "mfhierarchy$microflow"
 SET "usages" = 0;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('a1211b49-9012-4d30-b981-9827700554fd', 
'7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'Usages', 
'usages', 
3, 
0, 
'0', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('0e61a42f-50ab-4afb-95e4-7b57241b0df6', 
'7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'Actions', 
'actions', 
3, 
0, 
'0', 
false);
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151113 16:35:17';
