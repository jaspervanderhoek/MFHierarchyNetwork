DROP INDEX "idx_mfhierarchy$activity_microflowcall_mfhierarchy$microflow_mfhierarchy$activity";
ALTER TABLE "mfhierarchy$activity_microflowcall" RENAME TO "6bdfd26cfc234d63965bff7ead205978";
DELETE FROM "mendixsystem$association" 
 WHERE "id" = '583b3b6c-23eb-45f2-8f83-22bbb8eda6af';
ALTER TABLE "mfhierarchy$microflow"
	DROP COLUMN "actions";
ALTER TABLE "mfhierarchy$microflow"
	DROP COLUMN "usages";
ALTER TABLE "mfhierarchy$microflow"
	DROP COLUMN "name";
DELETE FROM "mendixsystem$attribute" 
 WHERE "id" = '0e61a42f-50ab-4afb-95e4-7b57241b0df6';
DELETE FROM "mendixsystem$attribute" 
 WHERE "id" = '2c1d5f95-4939-3176-a204-9adb827fe658';
DELETE FROM "mendixsystem$attribute" 
 WHERE "id" = '8d0f3b4b-840c-46e0-8793-61de1f9553ec';
DELETE FROM "mendixsystem$attribute" 
 WHERE "id" = 'a1211b49-9012-4d30-b981-9827700554fd';
UPDATE "mendixsystem$entity"
 SET "entity_name" = 'MFHierarchy.Microflow', 
"table_name" = 'mfhierarchy$microflow', 
"superentity_id" = '09449d31-6812-4bb2-9506-efeb57486913'
 WHERE "id" = '7fccd723-6287-45f1-9279-7b06c1a7b6b0';
CREATE TABLE "mfhierarchy$appserviceaction" (
	"id" BIGINT NOT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name", 
"superentity_id")
 VALUES ('f0ebb79f-fa4b-425e-9826-11650a951882', 
'MFHierarchy.AppServiceAction', 
'mfhierarchy$appserviceaction', 
'09449d31-6812-4bb2-9506-efeb57486913');
CREATE TABLE "mfhierarchy$action" (
	"id" BIGINT NOT NULL,
	"name" VARCHAR_IGNORECASE(200) NULL,
	"changeddate" TIMESTAMP NULL,
	"actiontype" VARCHAR_IGNORECASE(10) NULL,
	"usages" INT NULL,
	"actions" INT NULL,
	"submetaobjectname" VARCHAR_IGNORECASE(255) NULL,
	PRIMARY KEY("id"));
CREATE INDEX "idx_mfhierarchy$action_submetaobjectname" ON "mfhierarchy$action"
	("submetaobjectname","id");
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name")
 VALUES ('09449d31-6812-4bb2-9506-efeb57486913', 
'MFHierarchy.Action', 
'mfhierarchy$action');
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('f059eabd-6351-4636-b983-1f679db0b8f3', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'Name', 
'name', 
30, 
200, 
'', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('b4e82640-9e65-3114-89c3-e044329dace2', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'changedDate', 
'changeddate', 
20, 
0, 
'', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('35693c52-6bd8-482d-8cc0-d598da5e4137', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'ActionType', 
'actiontype', 
40, 
10, 
'', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('208938a4-451b-45d2-a821-95fdf8c9b155', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'Usages', 
'usages', 
3, 
0, 
'0', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('85150c67-46b0-4b1c-948f-d20b98b02795', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'Actions', 
'actions', 
3, 
0, 
'0', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('04957119-5416-3b66-bb2a-668b73e9a72b', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'submetaobjectname', 
'submetaobjectname', 
30, 
255, 
'MFHierarchy.Action', 
false);
INSERT INTO "mendixsystem$index" ("id", 
"table_id", 
"index_name")
 VALUES ('1cc64030-c80f-3c0a-9afa-073d0081c167', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'idx_mfhierarchy$action_submetaobjectname');
INSERT INTO "mendixsystem$index_column" ("index_id", 
"column_id", 
"sort_order", 
"ordinal")
 VALUES ('1cc64030-c80f-3c0a-9afa-073d0081c167', 
'04957119-5416-3b66-bb2a-668b73e9a72b', 
false, 
0);
CREATE TABLE "mfhierarchy$activity_microflowcall" (
	"mfhierarchy$activityid" BIGINT NOT NULL,
	"mfhierarchy$actionid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$activityid","mfhierarchy$actionid"));
CREATE INDEX "idx_mfhierarchy$activity_microflowcall_mfhierarchy$action_mfhierarchy$activity" ON "mfhierarchy$activity_microflowcall"
	("mfhierarchy$actionid","mfhierarchy$activityid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('1eb96786-3639-4622-a1ac-43df7f7f79a7', 
'MFHierarchy.Activity_MicroflowCall', 
'mfhierarchy$activity_microflowcall', 
'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'mfhierarchy$activityid', 
'mfhierarchy$actionid', 
'idx_mfhierarchy$activity_microflowcall_mfhierarchy$action_mfhierarchy$activity');
CREATE TABLE "mfhierarchy$webserviceaction" (
	"id" BIGINT NOT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name", 
"superentity_id")
 VALUES ('9e0dea90-3608-4599-8a0b-fd2f36db54bc', 
'MFHierarchy.WebServiceAction', 
'mfhierarchy$webserviceaction', 
'09449d31-6812-4bb2-9506-efeb57486913');
CREATE TABLE "mfhierarchy$javaaction" (
	"id" BIGINT NOT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name", 
"superentity_id")
 VALUES ('cf9fd30b-abbb-4a81-ab9f-af9f81423e86', 
'MFHierarchy.JavaAction', 
'mfhierarchy$javaaction', 
'09449d31-6812-4bb2-9506-efeb57486913');
INSERT INTO "mfhierarchy$action" ("id", 
"submetaobjectname", 
"changeddate", 
"usages", 
"actions")
SELECT "id", 
'MFHierarchy.Microflow', 
"changeddate", 
0, 
0
 FROM "mfhierarchy$microflow"
 ORDER BY "id" ASC;
ALTER TABLE "mfhierarchy$microflow"
	DROP COLUMN "changeddate";
DROP TABLE "6bdfd26cfc234d63965bff7ead205978";
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151118 11:50:34';
