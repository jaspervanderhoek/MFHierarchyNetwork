ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "displayqty" INT NULL;
UPDATE "mfhierarchy$diagramfilter"
 SET "displayqty" = 0;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('d0bd27cb-807c-4cc1-b675-768c1ec33df6', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'DisplayQty', 
'displayqty', 
3, 
0, 
'0', 
false);
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151210 13:56:43';
