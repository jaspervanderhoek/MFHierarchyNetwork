ALTER TABLE "mfhierarchy$microflow"
	ADD "color" VARCHAR_IGNORECASE(10) NULL;
UPDATE "mfhierarchy$microflow"
 SET "color" = '#E4EDFA';
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('372739fb-7c25-48e5-bac5-7d5ba22162ab', 
'7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'Color', 
'color', 
30, 
10, 
'#E4EDFA', 
false);
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151117 13:34:13';
