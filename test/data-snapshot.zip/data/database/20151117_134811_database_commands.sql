ALTER TABLE "mfhierarchy$microflow"
	DROP COLUMN "color";
DELETE FROM "mendixsystem$attribute" 
 WHERE "id" = '372739fb-7c25-48e5-bac5-7d5ba22162ab';
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151117 13:47:44';
