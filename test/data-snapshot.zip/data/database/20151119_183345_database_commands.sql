DROP INDEX "idx_mfhierarchy$diagramfilter_microflow_mfhierarchy$microflow_mfhierarchy$diagramfilter";
ALTER TABLE "mfhierarchy$diagramfilter_microflow" RENAME TO "b2e3c54846ab46bdbb9a47874e6e67d9";
DROP INDEX "idx_mfhierarchy$diagramfilter_action_mfhierarchy$action_mfhierarchy$diagramfilter";
DROP INDEX "idx_mfhierarchy$diagramfilter_action_single_mfhierarchy$action_mfhierarchy$diagramfilter";
DROP INDEX "idx_mfhierarchy$activity_microflowcall_mfhierarchy$action_mfhierarchy$activity";
ALTER TABLE "mfhierarchy$diagramfilter_action" RENAME TO "mfhierarchy$diagramfilter_manualactionfilter";
ALTER TABLE "mfhierarchy$diagramfilter_action_single" RENAME TO "mfhierarchy$diagramfilter_manualactionfilter_selectsingle";
ALTER TABLE "mfhierarchy$activity_microflowcall" RENAME TO "mfhierarchy$activity_actioncall";
DELETE FROM "mendixsystem$association" 
 WHERE "id" = '9c7a48e9-f4e6-45e7-9aef-c392244232e9';
CREATE INDEX "idx_mfhierarchy$diagramfilter_manualactionfilter_mfhierarchy$action_mfhierarchy$diagramfilter" ON "mfhierarchy$diagramfilter_manualactionfilter"
	("mfhierarchy$actionid","mfhierarchy$diagramfilterid");
UPDATE "mendixsystem$association"
 SET "association_name" = 'MFHierarchy.DiagramFilter_ManualActionFilter', 
"table_name" = 'mfhierarchy$diagramfilter_manualactionfilter', 
"parent_entity_id" = '216ebd34-4b42-43b4-8f29-2abb49a75756', 
"child_entity_id" = '09449d31-6812-4bb2-9506-efeb57486913', 
"parent_column_name" = 'mfhierarchy$diagramfilterid', 
"child_column_name" = 'mfhierarchy$actionid', 
"pk_index_name" = NULL, 
"index_name" = 'idx_mfhierarchy$diagramfilter_manualactionfilter_mfhierarchy$action_mfhierarchy$diagramfilter'
 WHERE "id" = 'e2aa02e2-9636-48c3-9d59-b90d7d0f0432';
CREATE TABLE "mfhierarchy$diagramfilter_fullnetworkfilter" (
	"mfhierarchy$diagramfilterid" BIGINT NOT NULL,
	"mfhierarchy$actionid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$diagramfilterid","mfhierarchy$actionid"));
CREATE INDEX "idx_mfhierarchy$diagramfilter_fullnetworkfilter_mfhierarchy$action_mfhierarchy$diagramfilter" ON "mfhierarchy$diagramfilter_fullnetworkfilter"
	("mfhierarchy$actionid","mfhierarchy$diagramfilterid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('d8c9a4c2-5268-40fc-8198-85a5e569ea97', 
'MFHierarchy.DiagramFilter_FullNetworkFilter', 
'mfhierarchy$diagramfilter_fullnetworkfilter', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'mfhierarchy$diagramfilterid', 
'mfhierarchy$actionid', 
'idx_mfhierarchy$diagramfilter_fullnetworkfilter_mfhierarchy$action_mfhierarchy$diagramfilter');
CREATE INDEX "idx_mfhierarchy$diagramfilter_manualactionfilter_selectsingle_mfhierarchy$action_mfhierarchy$diagramfilter" ON "mfhierarchy$diagramfilter_manualactionfilter_selectsingle"
	("mfhierarchy$actionid","mfhierarchy$diagramfilterid");
UPDATE "mendixsystem$association"
 SET "association_name" = 'MFHierarchy.DiagramFilter_ManualActionFilter_SelectSingle', 
"table_name" = 'mfhierarchy$diagramfilter_manualactionfilter_selectsingle', 
"parent_entity_id" = '216ebd34-4b42-43b4-8f29-2abb49a75756', 
"child_entity_id" = '09449d31-6812-4bb2-9506-efeb57486913', 
"parent_column_name" = 'mfhierarchy$diagramfilterid', 
"child_column_name" = 'mfhierarchy$actionid', 
"pk_index_name" = NULL, 
"index_name" = 'idx_mfhierarchy$diagramfilter_manualactionfilter_selectsingle_mfhierarchy$action_mfhierarchy$diagramfilter'
 WHERE "id" = '327505b9-5b30-4843-a128-153c6775f12a';
CREATE INDEX "idx_mfhierarchy$activity_actioncall_mfhierarchy$action_mfhierarchy$activity" ON "mfhierarchy$activity_actioncall"
	("mfhierarchy$actionid","mfhierarchy$activityid");
UPDATE "mendixsystem$association"
 SET "association_name" = 'MFHierarchy.Activity_ActionCall', 
"table_name" = 'mfhierarchy$activity_actioncall', 
"parent_entity_id" = 'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
"child_entity_id" = '09449d31-6812-4bb2-9506-efeb57486913', 
"parent_column_name" = 'mfhierarchy$activityid', 
"child_column_name" = 'mfhierarchy$actionid', 
"pk_index_name" = NULL, 
"index_name" = 'idx_mfhierarchy$activity_actioncall_mfhierarchy$action_mfhierarchy$activity'
 WHERE "id" = '1eb96786-3639-4622-a1ac-43df7f7f79a7';
DROP TABLE "b2e3c54846ab46bdbb9a47874e6e67d9";
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151119 18:33:38';
