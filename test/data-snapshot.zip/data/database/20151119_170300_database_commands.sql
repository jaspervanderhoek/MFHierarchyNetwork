ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "filteronmodules" BOOLEAN NULL;
UPDATE "mfhierarchy$diagramfilter"
 SET "filteronmodules" = true;
ALTER TABLE "mfhierarchy$diagramfilter"
	ADD "includeusedmicroflows" BOOLEAN NULL;
UPDATE "mfhierarchy$diagramfilter"
 SET "includeusedmicroflows" = true;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('2d42addd-2559-44b0-a018-28bfca34e36a', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'FilterOnModules', 
'filteronmodules', 
10, 
0, 
'true', 
false);
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('826bec70-defc-41fb-8584-77b904a0652c', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'IncludeUsedMicroflows', 
'includeusedmicroflows', 
10, 
0, 
'true', 
false);
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151119 17:02:57';
