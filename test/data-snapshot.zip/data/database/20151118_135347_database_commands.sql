ALTER TABLE "mfhierarchy$action"
	DROP COLUMN "actions";
ALTER TABLE "mfhierarchy$action"
	ADD "size" INT NULL;
UPDATE "mfhierarchy$action"
 SET "size" = 10;
ALTER TABLE "mfhierarchy$action" ALTER COLUMN "name" SET DATA TYPE VARCHAR_IGNORECASE(400);
DELETE FROM "mendixsystem$attribute" 
 WHERE "id" = '85150c67-46b0-4b1c-948f-d20b98b02795';
UPDATE "mendixsystem$attribute"
 SET "entity_id" = '09449d31-6812-4bb2-9506-efeb57486913', 
"attribute_name" = 'Name', 
"column_name" = 'name', 
"type" = 30, 
"length" = 400, 
"default_value" = '', 
"is_auto_number" = false
 WHERE "id" = 'f059eabd-6351-4636-b983-1f679db0b8f3';
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('8c37bb9a-8773-46a1-b5bb-d04460ed414f', 
'09449d31-6812-4bb2-9506-efeb57486913', 
'Size', 
'size', 
3, 
0, 
'10', 
false);
ALTER TABLE "mfhierarchy$activity"
	DROP COLUMN "activitytype";
ALTER TABLE "mfhierarchy$activity"
	ADD "activitytype" VARCHAR_IGNORECASE(10) NULL;
ALTER TABLE "mfhierarchy$activity"
	ADD "hovertext" VARCHAR_IGNORECASE(600) NULL;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('7b0cda47-90ff-48c6-b5a9-dd92e64539cf', 
'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
'HoverText', 
'hovertext', 
30, 
600, 
'', 
false);
UPDATE "mendixsystem$attribute"
 SET "entity_id" = 'cdadffb6-2791-4fcb-ba00-3ac6db905858', 
"attribute_name" = 'ActivityType', 
"column_name" = 'activitytype', 
"type" = 40, 
"length" = 10, 
"default_value" = '', 
"is_auto_number" = false
 WHERE "id" = '0126f1f2-b414-4dd0-a291-8156179b2a4e';
ALTER TABLE "mfhierarchy$microflow"
	ADD "actions" INT NULL;
UPDATE "mfhierarchy$microflow"
 SET "actions" = 0;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('cd066869-6736-4c46-b6fe-b628652f3f5a', 
'7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'Actions', 
'actions', 
3, 
0, 
'0', 
false);
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151118 13:11:13';
