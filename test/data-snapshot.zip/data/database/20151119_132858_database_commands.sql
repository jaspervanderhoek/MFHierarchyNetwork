ALTER TABLE "mfhierarchy$module"
	ADD "nrofmicroflows" INT NULL;
UPDATE "mfhierarchy$module"
 SET "nrofmicroflows" = 0;
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('185c422e-b414-4c58-b3ce-539e1fe4f558', 
'd245cab5-78ea-4607-a5eb-ae4a3447c4ec', 
'NrOfMicroflows', 
'nrofmicroflows', 
3, 
0, 
'0', 
false);
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151119 13:27:18';
