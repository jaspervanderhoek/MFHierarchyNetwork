CREATE TABLE "mfhierarchy$display" (
	"id" BIGINT NOT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name")
 VALUES ('216ebd34-4b42-43b4-8f29-2abb49a75756', 
'MFHierarchy.Display', 
'mfhierarchy$display');
CREATE TABLE "mfhierarchy$display_microflow" (
	"mfhierarchy$displayid" BIGINT NOT NULL,
	"mfhierarchy$microflowid" BIGINT NOT NULL,
	PRIMARY KEY("mfhierarchy$displayid","mfhierarchy$microflowid"));
CREATE INDEX "idx_mfhierarchy$display_microflow_mfhierarchy$microflow_mfhierarchy$display" ON "mfhierarchy$display_microflow"
	("mfhierarchy$microflowid","mfhierarchy$displayid");
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('9c7a48e9-f4e6-45e7-9aef-c392244232e9', 
'MFHierarchy.Display_Microflow', 
'mfhierarchy$display_microflow', 
'216ebd34-4b42-43b4-8f29-2abb49a75756', 
'7fccd723-6287-45f1-9279-7b06c1a7b6b0', 
'mfhierarchy$displayid', 
'mfhierarchy$microflowid', 
'idx_mfhierarchy$display_microflow_mfhierarchy$microflow_mfhierarchy$display');
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.0.7', 
"lastsyncdate" = '20151117 10:00:03';
